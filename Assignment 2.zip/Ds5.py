# Factorial of a Number

# Accept a positive integer from the user
num = int(input("Enter a number: "))

# Initialize factorial
fact = 1

# Use a for loop to calculate factorial
for i in range(1, num + 1):
    fact *= i

# Display the result
print("Factorial =", fact)
