# Count Even and Odd Numbers between 1 and N

# Accept a number N
N = int(input("Enter N: "))

# Initialize counters
even_count = 0
odd_count = 0

# Use a for loop to check each number
for i in range(1, N + 1):
    if i % 2 == 0:
        even_count += 1
    else:
        odd_count += 1

# Display results
print("Even Numbers:", even_count)
print("Odd Numbers:", odd_count)
