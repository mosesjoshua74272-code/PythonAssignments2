# Sum of Digits

# Accept a number
num = int(input("Enter N: "))

# Initialize sum
digit_sum = 0

# Use while loop to extract digits
while num > 0:
    digit_sum += num % 10   # add last digit
    num //= 10              # remove last digit

# Display result
print("Sum =", digit_sum)
