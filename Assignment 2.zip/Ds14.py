# Create an empty list to store five numbers
numbers = []

# Ask the user to enter five numbers
for i in range(5):
    num = int(input("Enter number: "))
    numbers.append(num)

# Ask the user for the number they want to search for
search = int(input("Enter Number to Search: "))

# Check if the search number exists in the list
if search in numbers:
    # Display this message if the number is found
    print(search, "is present in the list")
else:
    # Display this message if the number is not found
    print(search, "is not present in the list")
