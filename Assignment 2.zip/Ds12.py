# Program to find the largest element in a list

# Create an empty list
numbers = []

# Accept five numbers from the user
print("Enter 5 numbers:")

for i in range(5):
    num = int(input())
    numbers.append(num)

# Assume the first number is the largest
largest = numbers[0]

# Find the largest number
for num in numbers:
    if num > largest:
        largest = num

# Display the largest number
print("Largest Number =", largest)