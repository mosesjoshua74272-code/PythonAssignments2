# Print Numbers from 1 to N using a while loop

# Accept N from the user
N = int(input("Enter N: "))

# Initialize counter
i = 1

# Use while loop to print numbers
while i <= N:
    print(i)
    i += 1
