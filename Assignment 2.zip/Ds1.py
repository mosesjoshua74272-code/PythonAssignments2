# Print Numbers from 1 to 10

# Initialize counter
i = 1

# Use while loop to print numbers
while i <= 10:
    print(i)
    i += 1
