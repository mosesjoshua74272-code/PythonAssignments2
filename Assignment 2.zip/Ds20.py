# Convert Tuple to List

# Create a tuple
numbers_tuple = (10, 20, 30, 40, 50)

# Convert tuple into list
numbers_list = list(numbers_tuple)

# Display both
print("Tuple:", numbers_tuple)
print("List:", numbers_list)
