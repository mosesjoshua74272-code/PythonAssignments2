# Calculate Sum of List Elements

# Accept five numbers from the user
numbers = []
print("Enter 5 numbers:")
for i in range(5):
    num = int(input())
    numbers.append(num)

# Calculate the sum of elements
total_sum = sum(numbers)

# Display the result
print("Sum =", total_sum)
