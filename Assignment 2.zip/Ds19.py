# Check Element in Tuple

# Create a tuple
numbers = (10, 20, 30, 40, 50)

# Accept an element from the user
element = int(input("Enter Element: "))

# Check if element exists
if element in numbers:
    print("Element Found")
else:
    print("Element Not Found")
