# Create and Display a Tuple

# Accept five values from the user (space-separated)
values = tuple(map(int, input("Enter 5 numbers: ").split()))

# Display the tuple
print("Output:", values)
