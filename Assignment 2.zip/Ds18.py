# Find Maximum and Minimum in a Tuple

# Accept five numbers in one line (space-separated)
numbers = tuple(map(int, input("Enter 5 numbers: ").split()))

# Find maximum and minimum
maximum = max(numbers)
minimum = min(numbers)

# Display results
print("Maximum =", maximum, "Minimum =", minimum)
