# Count Occurrences in a Tuple

# Create a tuple
numbers = (10, 20, 30, 20, 40, 50)

# Accept a value to search
search_value = int(input("Enter Value: "))

# Count occurrences
count = numbers.count(search_value)

# Display result
print(search_value, "appears", count, "times.")
