# Program to create and display a list of five numbers

# Create an empty list
numbers = []

# Accept five numbers from the user
print("Enter 5 numbers:")

for i in range(5):
    num = int(input())
    numbers.append(num)

# Display the complete list
print("List:", numbers)