# Count Even and Odd Numbers in a List

# Accept five numbers in one line (space-separated)
numbers = list(map(int, input("Enter numbers: ").split()))

# Initialize counters
even_count = 0
odd_count = 0

# Count even and odd numbers
for num in numbers:
    if num % 2 == 0:
        even_count += 1
    else:
        odd_count += 1

# Display results
print("Odd Numbers:", odd_count)
print("Even Numbers:", even_count)
