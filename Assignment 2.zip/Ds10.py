# Program to count the number of digits in a given integer

# Accept a number from the user
num = int(input("Enter Number: "))

# Initialize the digit count
count = 0

# If the number is 0, it has one digit
if num == 0:
    count = 1
else:
    # Make the number positive if it is negative
    num = abs(num)

    # Count the digits using a while loop
    while num > 0:
        count = count + 1
        num = num // 10

# Display the total number of digits
print("Total Digits =", count)