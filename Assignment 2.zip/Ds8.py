# Reverse a Number

# Accept an integer
num = int(input("Enter Number: "))

# Initialize reverse
reverse_num = 0

# Use while loop to reverse digits
while num > 0:
    digit = num % 10
    reverse_num = reverse_num * 10 + digit
    num //= 10

# Display result
print(reverse_num)
