# Program to print the multiplication table of a number

# Accept a number from the user
num = int(input("Enter Number: "))

# Start the counter from 1
i = 1

# Print the table from 1 to 10
while i <= 10:
    print(num, "x", i, "=", num * i)
    
    # Increase the counter by 1
    i += 1