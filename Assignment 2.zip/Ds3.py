# Sum of First N Numbers

# Accept a positive integer from the user
N = int(input("Enter N: "))

# Initialize sum
total = 0

# Use a for loop to add numbers from 1 to N
for i in range(1, N + 1):
    total += i

# Display the result
print("Sum =", total)
